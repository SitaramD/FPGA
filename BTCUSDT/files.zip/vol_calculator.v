// ============================================================
// vol_calculator.v — Volatility Adjustment Calculator
// SITARAM BTCUSDT Order Book Processor
//
// Method: Rolling standard deviation of mid-price returns
//         over last 50 ticks (REGIME_VOL_WINDOW=50)
//
// mid_price = (best_bid + best_ask) / 2
// return[i] = mid[i] - mid[i-1]
// vol = sqrt( sum((return - mean)^2) / N )
//
// Output vol_scaled: volatility * 10^12 for regime comparison
//
// Clock: 100 MHz (Kria KV260 PL)
// ============================================================
`include "ob_params.v"

module vol_calculator (
    input  wire                 clk,
    input  wire                 rst_n,
    input  wire                 valid_in,

    // Best bid and ask prices (scaled x10, e.g. $66970.6 → 669706)
    input  wire [`PRICE_W-1:0] best_bid,
    input  wire [`PRICE_W-1:0] best_ask,

    output reg  [`VOL_W-1:0]   vol_scaled,     // volatility * 10^12
    output reg  [1:0]           regime,         // 00=LOW 01=MED 10=HIGH
    output reg                  valid_out
);

    // ── Mid price calculation ─────────────────────────────────────────────
    wire [`PRICE_W:0] mid_price = (best_bid + best_ask) >> 1; // /2

    // ── Rolling window buffer for mid prices ──────────────────────────────
    reg signed [`PRICE_W:0] mid_buf    [`VOL_WINDOW-1:0];
    reg signed [`PRICE_W:0] return_buf [`VOL_WINDOW-1:0]; // price diffs
    reg        [5:0]         fill_count;   // how many ticks received so far
    reg        [5:0]         ptr;          // circular buffer pointer

    // ── Accumulator for mean and variance ────────────────────────────────
    reg signed [`VOL_W-1:0]  sum_ret;
    reg signed [`VOL_W-1:0]  sum_sq;
    integer i;

    // ── Integer square root (Newton-Raphson, 16 iterations) ──────────────
    function [`VOL_W-1:0] isqrt;
        input [`VOL_W-1:0] n;
        reg [`VOL_W-1:0] x, x_next;
        integer j;
        begin
            if (n == 0) begin
                isqrt = 0;
            end else begin
                x = n;
                for (j = 0; j < 16; j = j + 1) begin
                    x_next = (x + n/x) >> 1;
                    if (x_next >= x) begin
                        x = x; // converged
                    end else begin
                        x = x_next;
                    end
                end
                isqrt = x;
            end
        end
    endfunction

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            fill_count <= 6'd0;
            ptr        <= 6'd0;
            vol_scaled <= 64'd0;
            regime     <= `REGIME_LOW;
            valid_out  <= 1'b0;
            sum_ret    <= 64'sd0;
            sum_sq     <= 64'sd0;
            for (i = 0; i < `VOL_WINDOW; i = i + 1) begin
                mid_buf[i]    <= 0;
                return_buf[i] <= 0;
            end
        end else if (valid_in) begin

            // ── Store new mid price ───────────────────────────────────────
            mid_buf[ptr] <= $signed({1'b0, mid_price});

            // ── Compute return = current mid - previous mid ───────────────
            if (fill_count > 0) begin
                return_buf[ptr] <= $signed({1'b0, mid_price})
                                 - mid_buf[(ptr == 0) ?
                                   `VOL_WINDOW-1 : ptr-1];
            end else begin
                return_buf[ptr] <= 64'sd0;
            end

            // ── Advance pointer ───────────────────────────────────────────
            ptr        <= (ptr == `VOL_WINDOW-1) ? 6'd0 : ptr + 1;
            fill_count <= (fill_count < `VOL_WINDOW) ?
                           fill_count + 1 : fill_count;

            // ── Compute mean of returns ───────────────────────────────────
            if (fill_count >= `VOL_WINDOW) begin
                sum_ret = 64'sd0;
                for (i = 0; i < `VOL_WINDOW; i = i + 1)
                    sum_ret = sum_ret + return_buf[i];

                // mean_ret = sum_ret / VOL_WINDOW
                // Use sum_ret directly (avoid division — small error OK)

                // ── Compute variance = sum((ret)^2) / N ──────────────────
                sum_sq = 64'sd0;
                for (i = 0; i < `VOL_WINDOW; i = i + 1)
                    sum_sq = sum_sq + (return_buf[i] * return_buf[i]);

                // variance = sum_sq / VOL_WINDOW
                // vol = sqrt(variance)
                // vol_scaled = vol * 10^12 / PRICE_SCALE^2
                // (because prices are scaled x10, returns are scaled x10 too)
                // vol_real = sqrt(sum_sq / 50) / 10  (unscale price)

                vol_scaled <= isqrt(sum_sq / `VOL_WINDOW);

                // ── Regime detection ──────────────────────────────────────
                // REGIME_LOW_THRESH  = 20000000 (~2e-5)
                // REGIME_HIGH_THRESH = 60000000 (~6e-5)
                if (isqrt(sum_sq / `VOL_WINDOW) < `REGIME_LOW_THRESH)
                    regime <= `REGIME_LOW;
                else if (isqrt(sum_sq / `VOL_WINDOW) < `REGIME_HIGH_THRESH)
                    regime <= `REGIME_MEDIUM;
                else
                    regime <= `REGIME_HIGH;

                valid_out <= 1'b1;
            end else begin
                valid_out <= 1'b0;
            end
        end else begin
            valid_out <= 1'b0;
        end
    end

endmodule
