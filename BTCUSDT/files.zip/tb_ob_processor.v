// ============================================================
// tb_ob_processor.v — Testbench for SITARAM OB Processor
// SITARAM BTCUSDT Order Book Processor
//
// Reads tick data from C++ stdin pipe via $fscanf
// Input file format (one tick):
//   TICK <tick_number>
//   BID <price_scaled> <qty_scaled>   × 200 lines
//   ASK <price_scaled> <qty_scaled>   × 200 lines
//   END
//
// Displays formatted output to ModelSim console
// Clock: 100 MHz simulation
// ============================================================
`include "ob_params.v"
`timescale 1ns/1ps

module tb_ob_processor;

    // ── Clock & Reset ─────────────────────────────────────────────────────
    reg clk   = 0;
    reg rst_n = 0;
    always #5 clk = ~clk;   // 100 MHz → 10ns period

    // ── DUT signals ───────────────────────────────────────────────────────
    reg                  tick_valid;
    reg [`PRICE_W-1:0]   bid_price [0:`OB_LEVELS-1];
    reg [`QTY_W-1:0]     bid_qty   [0:`OB_LEVELS-1];
    reg [`PRICE_W-1:0]   ask_price [0:`OB_LEVELS-1];
    reg [`QTY_W-1:0]     ask_qty   [0:`OB_LEVELS-1];

    wire signed [31:0]   obi_out;
    wire [`VOL_W-1:0]    vol_out;
    wire [1:0]           regime_out;
    wire                 obi_valid;
    wire                 vol_valid;

    // ── DUT instantiation ─────────────────────────────────────────────────
    ob_processor dut (
        .clk        (clk),
        .rst_n      (rst_n),
        .tick_valid (tick_valid),
        .bid_price  (bid_price),
        .bid_qty    (bid_qty),
        .ask_price  (ask_price),
        .ask_qty    (ask_qty),
        .obi_out    (obi_out),
        .vol_out    (vol_out),
        .regime_out (regime_out),
        .obi_valid  (obi_valid),
        .vol_valid  (vol_valid)
    );

    // ── File handle & loop vars ───────────────────────────────────────────
    integer fd;
    integer tick_num, i, scan_ret;
    reg [8*4-1:0]  token;       // 4-char string token (TICK/BID/ASK/END)
    reg [31:0]     tmp_price, tmp_qty;

    // ── Formatted display task ────────────────────────────────────────────
    task display_results;
        input integer tick_id;
        input signed [31:0] obi;
        input [`VOL_W-1:0]  vol;
        input [1:0]          reg_flag;
        input [`PRICE_W-1:0] bbid;
        input [`PRICE_W-1:0] bask;
        reg [8*6-1:0] regime_str;
        integer mid_int, mid_frac;
        integer obi_int, obi_frac, obi_sign;
        begin
            // Regime string
            case (reg_flag)
                `REGIME_LOW    : regime_str = "LOW   ";
                `REGIME_MEDIUM : regime_str = "MEDIUM";
                `REGIME_HIGH   : regime_str = "HIGH  ";
                default        : regime_str = "???   ";
            endcase

            // Mid price (unscale: divide by PRICE_SCALE=10)
            mid_int  = (bbid + bask) / 2 / `PRICE_SCALE;
            mid_frac = (bbid + bask) / 2 % `PRICE_SCALE;

            // OBI sign and value
            if ($signed(obi) < 0) begin
                obi_sign = 1;
                obi_int  = (-$signed(obi)) / 10000;
                obi_frac = (-$signed(obi)) % 10000;
            end else begin
                obi_sign = 0;
                obi_int  = $signed(obi) / 10000;
                obi_frac = $signed(obi) % 10000;
            end

            $display("╔══════════════════════════════════════════════╗");
            $display("║     SITARAM OB PROCESSOR — TICK #%0d         ║", tick_id);
            $display("╠══════════════════════════════════════════════╣");
            $display("║  Mid Price  : $%0d.%0d                        ║",
                      mid_int, mid_frac);
            $display("║  Best Bid   : $%0d.%0d                        ║",
                      bbid / `PRICE_SCALE, bbid % `PRICE_SCALE);
            $display("║  Best Ask   : $%0d.%0d                        ║",
                      bask / `PRICE_SCALE, bask % `PRICE_SCALE);
            $display("║  Spread     : $%0d.%0d                        ║",
                      (bask - bbid) / `PRICE_SCALE,
                      (bask - bbid) % `PRICE_SCALE);
            $display("╠══════════════════════════════════════════════╣");
            if (obi_sign)
                $display("║  OBI (top5) : -%0d.%04d                      ║",
                          obi_int, obi_frac);
            else
                $display("║  OBI (top5) : +%0d.%04d                      ║",
                          obi_int, obi_frac);
            $display("║  Volatility : %0d (scaled)                   ║", vol);
            $display("║  Regime     : %s                          ║", regime_str);
            $display("╚══════════════════════════════════════════════╝");
            $display("");
        end
    endtask

    // ── Main simulation ───────────────────────────────────────────────────
    initial begin
        tick_valid = 0;

        // Reset for 5 cycles
        #10 rst_n = 1;
        $display("================================================");
        $display("  SITARAM BTCUSDT OB PROCESSOR — ModelSim Sim  ");
        $display("  Clock: 100MHz | Fixed-point: 32-bit scaled    ");
        $display("  OBI: Top-5 | Vol Window: 50 ticks             ");
        $display("================================================");
        $display("");

        // Open stdin pipe from C++ feeder
        fd = $fopen("input_pipe.txt", "r");
        if (fd == 0) begin
            $display("ERROR: Cannot open input_pipe.txt");
            $display("Please run: ./ob_feeder > input_pipe.txt first");
            $finish;
        end

        tick_num = 0;

        // ── Read ticks in a loop ──────────────────────────────────────────
        while (!$feof(fd)) begin
            scan_ret = $fscanf(fd, "%s", token);
            if (scan_ret != 1) disable forever_block;

            if (token == "TICK") begin
                scan_ret = $fscanf(fd, "%d", tick_num);

                // Read 200 bids
                for (i = 0; i < `OB_LEVELS; i = i + 1) begin
                    scan_ret = $fscanf(fd, "%s %d %d", token, tmp_price, tmp_qty);
                    bid_price[i] = tmp_price;
                    bid_qty[i]   = tmp_qty;
                end

                // Read 200 asks
                for (i = 0; i < `OB_LEVELS; i = i + 1) begin
                    scan_ret = $fscanf(fd, "%s %d %d", token, tmp_price, tmp_qty);
                    ask_price[i] = tmp_price;
                    ask_qty[i]   = tmp_qty;
                end

                // Read END token
                scan_ret = $fscanf(fd, "%s", token);

                // ── Apply tick to DUT ─────────────────────────────────────
                @(posedge clk);
                tick_valid = 1;
                @(posedge clk);
                tick_valid = 0;

                // Wait for results (1 clock cycle pipeline)
                @(posedge clk);
                #1; // small settle

                // ── Display results ───────────────────────────────────────
                if (obi_valid) begin
                    display_results(
                        tick_num,
                        obi_out,
                        vol_out,
                        regime_out,
                        bid_price[0],
                        ask_price[0]
                    );
                end else begin
                    $display("[TICK %0d] Warming up... (%0d/50 ticks for vol)",
                              tick_num, tick_num);
                end

                // Small gap between ticks
                repeat(2) @(posedge clk);
            end
        end

        : forever_block

        $fclose(fd);
        $display("================================================");
        $display("  Simulation Complete");
        $display("================================================");
        $finish;
    end

    // ── Timeout watchdog ──────────────────────────────────────────────────
    initial begin
        #10_000_000; // 10ms timeout
        $display("TIMEOUT — simulation took too long");
        $finish;
    end

endmodule
