# ============================================================
# run_sim.do — ModelSim Simulation Script
# SITARAM BTCUSDT Order Book Processor
#
# Usage inside ModelSim console:
#   do run_sim.do
#
# Or from command line:
#   vsim -do run_sim.do -c
# ============================================================

# ── Step 1: Create fresh work library ────────────────────────────────────
vdel -all
vlib work
vmap work work

# ── Step 2: Compile RTL files ─────────────────────────────────────────────
echo ">>> Compiling RTL..."
vlog -work work +incdir+../rtl ../rtl/ob_params.v
vlog -work work +incdir+../rtl ../rtl/obi_calculator.v
vlog -work work +incdir+../rtl ../rtl/vol_calculator.v
vlog -work work +incdir+../rtl ../rtl/ob_processor.v

# ── Step 3: Compile testbench ─────────────────────────────────────────────
echo ">>> Compiling Testbench..."
vlog -work work +incdir+../rtl ../tb/tb_ob_processor.v

# ── Step 4: Run simulation ────────────────────────────────────────────────
echo ">>> Starting Simulation..."
vsim -c work.tb_ob_processor -do "run -all; quit"
