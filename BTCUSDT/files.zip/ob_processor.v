// ============================================================
// ob_processor.v — Top-Level Order Book Processor
// SITARAM BTCUSDT Order Book Processor
//
// Instantiates:
//   - obi_calculator  (OBI from top-5 levels)
//   - vol_calculator  (Volatility from 50-tick rolling window)
//
// Accepts 200 bids + 200 asks per tick
// Extracts top-5 for OBI, best bid/ask for volatility
// Clock: 100 MHz (Kria KV260 PL)
// ============================================================
`include "ob_params.v"

module ob_processor (
    input  wire                 clk,
    input  wire                 rst_n,
    input  wire                 tick_valid,     // new tick strobe

    // ── 200 Bid prices and quantities (sorted best→worst) ────────────────
    input  wire [`PRICE_W-1:0] bid_price [0:`OB_LEVELS-1],
    input  wire [`QTY_W-1:0]   bid_qty   [0:`OB_LEVELS-1],

    // ── 200 Ask prices and quantities (sorted best→worst) ────────────────
    input  wire [`PRICE_W-1:0] ask_price [0:`OB_LEVELS-1],
    input  wire [`QTY_W-1:0]   ask_qty   [0:`OB_LEVELS-1],

    // ── Outputs ───────────────────────────────────────────────────────────
    output wire signed [31:0]  obi_out,        // OBI x10000 signed
    output wire [`VOL_W-1:0]   vol_out,        // volatility scaled
    output wire [1:0]           regime_out,     // 00=LOW 01=MED 10=HIGH
    output wire                 obi_valid,
    output wire                 vol_valid
);

    // ── OBI Calculator (top-5 only) ───────────────────────────────────────
    obi_calculator u_obi (
        .clk        (clk),
        .rst_n      (rst_n),
        .valid_in   (tick_valid),
        .bid_qty_0  (bid_qty[0]),
        .bid_qty_1  (bid_qty[1]),
        .bid_qty_2  (bid_qty[2]),
        .bid_qty_3  (bid_qty[3]),
        .bid_qty_4  (bid_qty[4]),
        .ask_qty_0  (ask_qty[0]),
        .ask_qty_1  (ask_qty[1]),
        .ask_qty_2  (ask_qty[2]),
        .ask_qty_3  (ask_qty[3]),
        .ask_qty_4  (ask_qty[4]),
        .obi_out    (obi_out),
        .valid_out  (obi_valid)
    );

    // ── Volatility Calculator (best bid/ask = index 0) ────────────────────
    vol_calculator u_vol (
        .clk        (clk),
        .rst_n      (rst_n),
        .valid_in   (tick_valid),
        .best_bid   (bid_price[0]),
        .best_ask   (ask_price[0]),
        .vol_scaled (vol_out),
        .regime     (regime_out),
        .valid_out  (vol_valid)
    );

endmodule
